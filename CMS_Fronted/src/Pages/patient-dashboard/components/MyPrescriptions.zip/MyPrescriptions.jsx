import React, { useCallback, useEffect, useState } from 'react';
import { getAllPrescriptions, getLastPrescription } from '../api/patientApi';
import EmptyState from './EmptyState';
import { PrescriptionIcon } from './icons';

// Same dName quirk as the Doctor entity used elsewhere — keep this in sync
// once you share the Prescription entity/controller.
function getDoctorName(doctor) {
  if (!doctor) return '—';
  return doctor.dName ?? doctor.dname ?? doctor.name ?? '—';
}

export default function MyPrescriptions({ patientId }) {
  const [prescriptions, setPrescriptions] = useState([]);
  const [lastPrescription, setLastPrescription] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const loadPrescriptions = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [all, last] = await Promise.all([
        getAllPrescriptions(patientId),
        getLastPrescription(patientId).catch(() => null), // no prescriptions yet is not a hard error
      ]);
      setPrescriptions(Array.isArray(all) ? all : all?.prescriptions || []);
      setLastPrescription(last);
    } catch (err) {
      setError(err.message || 'Could not load your prescriptions.');
    } finally {
      setLoading(false);
    }
  }, [patientId]);

  useEffect(() => {
    loadPrescriptions();
  }, [loadPrescriptions]);

  const activeCount = prescriptions.filter((p) => (p.status ?? 'active').toLowerCase() === 'active').length;

  return (
    <>
      <header className="page-header">
        <div>
          <h2 className="page-title">My Prescriptions</h2>
          <p className="page-subtitle">View and manage your prescribed medications and treatment records.</p>
        </div>
        <span className="top-pill">{activeCount || prescriptions.length} Active Prescriptions</span>
      </header>

      {lastPrescription && (
        <section className="card highlight-card">
          <div className="card-header">
            <div className="icon-circle"><PrescriptionIcon /></div>
            <div>
              <h3 className="card-title">Most Recent Prescription</h3>
              <p className="card-subtitle">
                From Dr. {lastPrescription.doctor?.dName ?? lastPrescription.doctor?.dname ?? lastPrescription.doctorName ?? '—'} on{' '}
                {lastPrescription.prescriptionDate ?? lastPrescription.date}
              </p>
            </div>
          </div>
          <p className="record-notes">
            {lastPrescription.notes ?? lastPrescription.medication ?? lastPrescription.medicineName ?? '—'}
          </p>
        </section>
      )}

      <section className="card">
        <div className="card-header">
          <div className="icon-circle"><PrescriptionIcon /></div>
          <div>
            <h3 className="card-title">Prescription Records</h3>
            <p className="card-subtitle">View prescribed medicines and treatment guidance.</p>
          </div>
        </div>

        {loading ? (
          <p className="state-text">Loading prescriptions...</p>
        ) : error ? (
          <p className="state-text state-error">{error}</p>
        ) : prescriptions.length === 0 ? (
          <EmptyState
            icon={<PrescriptionIcon />}
            title="No Prescriptions Found"
            subtitle="Your prescriptions will appear here after doctor consultations."
          />
        ) : (
          <div className="table-grid">
            <div className="table-grid-header grid-cols-prescriptions">
              <span>Doctor</span>
              <span>Date</span>
              <span>Medicine</span>
              <span>Dosage</span>
              <span>Notes</span>
            </div>
            {prescriptions.map((p) => {
              const id = p.prescriptionId ?? p.id;
              return (
                <div key={id} className="table-grid-row grid-cols-prescriptions">
                  <div className="doctor-name">Dr. {getDoctorName(p.doctor) !== '—' ? getDoctorName(p.doctor) : (p.doctorName ?? '—')}</div>
                  <div>{p.prescriptionDate ?? p.date}</div>
                  <div>{p.medicineName ?? p.medication}</div>
                  <div>{p.dosage ?? '—'}</div>
                  <div>{p.notes ?? '—'}</div>
                </div>
              );
            })}
          </div>
        )}
      </section>
    </>
  );
}
